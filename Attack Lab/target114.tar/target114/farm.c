/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_396()
{
    return 3281031256U;
}

void setval_352(unsigned *p)
{
    *p = 3281017062U;
}

void setval_186(unsigned *p)
{
    *p = 2425394264U;
}

unsigned getval_165()
{
    return 2428995848U;
}

unsigned getval_322()
{
    return 3284633928U;
}

unsigned getval_133()
{
    return 2417509450U;
}

unsigned addval_421(unsigned x)
{
    return x + 2445773128U;
}

void setval_262(unsigned *p)
{
    *p = 3347663068U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

void setval_206(unsigned *p)
{
    *p = 3526413961U;
}

unsigned addval_428(unsigned x)
{
    return x + 3281047961U;
}

unsigned addval_240(unsigned x)
{
    return x + 3221275273U;
}

unsigned getval_114()
{
    return 2425409225U;
}

void setval_141(unsigned *p)
{
    *p = 3222848137U;
}

void setval_388(unsigned *p)
{
    *p = 3526939017U;
}

unsigned getval_260()
{
    return 3222851209U;
}

unsigned getval_370()
{
    return 3263253117U;
}

unsigned addval_128(unsigned x)
{
    return x + 3286272344U;
}

void setval_271(unsigned *p)
{
    *p = 3767093342U;
}

void setval_313(unsigned *p)
{
    *p = 3720594057U;
}

unsigned getval_415()
{
    return 3677930137U;
}

void setval_394(unsigned *p)
{
    *p = 3353381192U;
}

void setval_375(unsigned *p)
{
    *p = 3525362345U;
}

void setval_371(unsigned *p)
{
    *p = 3682914713U;
}

unsigned getval_113()
{
    return 3767093347U;
}

void setval_363(unsigned *p)
{
    *p = 3353381192U;
}

unsigned getval_211()
{
    return 3525366153U;
}

void setval_104(unsigned *p)
{
    *p = 2429618657U;
}

unsigned getval_202()
{
    return 2429458839U;
}

void setval_460(unsigned *p)
{
    *p = 3284306336U;
}

void setval_235(unsigned *p)
{
    *p = 2447411528U;
}

unsigned addval_474(unsigned x)
{
    return x + 3252717896U;
}

unsigned getval_431()
{
    return 3281047169U;
}

unsigned addval_480(unsigned x)
{
    return x + 3264270729U;
}

void setval_245(unsigned *p)
{
    *p = 3525365385U;
}

unsigned addval_337(unsigned x)
{
    return x + 3286272332U;
}

unsigned getval_295()
{
    return 3516498010U;
}

unsigned addval_427(unsigned x)
{
    return x + 3375943337U;
}

unsigned getval_369()
{
    return 3223372489U;
}

unsigned addval_452(unsigned x)
{
    return x + 3531918985U;
}

void setval_475(unsigned *p)
{
    *p = 3682128265U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
